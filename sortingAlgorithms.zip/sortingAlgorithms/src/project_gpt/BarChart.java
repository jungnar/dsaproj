package project_gpt;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class BarChart extends JPanel {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private ArrayList<Integer> data;

    public BarChart(ArrayList<Integer> data) {
        this.data = data;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;

        int barWidth = getWidth() / data.size();
        int maxValue = getMaxValue(data);

        for (int i = 0; i < data.size(); i++) {
            int barHeight = (int) ((double) getHeight() * data.get(i) / maxValue);
            int x = i * barWidth;
            int y = getHeight() - barHeight;

            g2d.setColor(Color.BLUE);
            g2d.fillRect(x, y, barWidth, barHeight);

            g2d.setColor(Color.BLACK);
            g2d.drawRect(x, y, barWidth, barHeight);
        }
    }

    private int getMaxValue(ArrayList<Integer> data) {
        int maxValue = Integer.MIN_VALUE;
        for (Integer value : data) {
            if (value > maxValue) {
                maxValue = value;
            }
        }
        return maxValue;
    }

    public static void main(String[] args) {
        ArrayList<Integer> sampleData = new ArrayList<>();
        sampleData.add(20);
        sampleData.add(50);
        sampleData.add(30);
        sampleData.add(80);
        sampleData.add(40);

        JFrame frame = new JFrame("Bar Chart");
        BarChart barChart = new BarChart(sampleData);
        frame.add(barChart);
        frame.setSize(400, 300);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
