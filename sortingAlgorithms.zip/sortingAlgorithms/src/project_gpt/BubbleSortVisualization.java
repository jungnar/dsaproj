package project_gpt;

import javax.swing.*;
import java.awt.*;
import java.util.Arrays;

public class BubbleSortVisualization extends JPanel {
    private static final int BAR_WIDTH = 20;
    private static final int BAR_HEIGHT_MULTIPLIER = 5;
    private static final int DELAY_MS = 50;

    private int[] data;
    private int currentIdx = 0;
    private Timer timer;

    public BubbleSortVisualization() {
        data = generateData(30); // Change the size of the array here
        timer = new Timer(DELAY_MS, e -> {
            if (currentIdx < data.length) {
                bubbleSortStep();
                repaint();
                currentIdx++;
            } else {
                timer.stop();
            }
        });
        timer.start();
    }

    private void bubbleSortStep() {
        for (int i = 0; i < data.length - 1 - currentIdx; i++) {
            if (data[i] > data[i + 1]) {
                int temp = data[i];
                data[i] = data[i + 1];
                data[i + 1] = temp;
            }
        }
    }

    private int[] generateData(int size) {
        int[] arr = new int[size];
        for (int i = 0; i < size; i++) {
            arr[i] = (int) (Math.random() * 100); // Generate random values between 0 and 99
        }
        return arr;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;

        int x = 10;
        for (int value : data) {
            Color color = (Arrays.asList(Arrays.copyOfRange(data, 0, currentIdx + 1)).contains(value)) ? Color.GREEN : Color.RED;
            g2d.setColor(color);
            int barHeight = value * BAR_HEIGHT_MULTIPLIER;
            g2d.fillRect(x, getHeight() - barHeight, BAR_WIDTH, barHeight);
            x += BAR_WIDTH + 5;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Bubble Sort Visualization");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(800, 400);
            frame.add(new BubbleSortVisualization());
            frame.setVisible(true);
        });
    }
}
