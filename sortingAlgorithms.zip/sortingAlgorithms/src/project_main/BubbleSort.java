package project_main;

import java.awt.Color;
import java.awt.Graphics;

@SuppressWarnings("serial")
public class BubbleSort extends SortingPanel {

	private int red = -1;
	private int green = -1;
	
	public BubbleSort(int[] list) {
		super(list);
	}

	@Override
	public void reset() {
		red = -1;
		green = -1;		
	}

	@Override
	public void run() {
		try {
			boolean needNextPass = true;
			for (int k = 1; k < list.length && needNextPass; k++) {
				needNextPass = false;
				for (int i = 0; i < list.length - k; i++) {
					red = i;
					repaint();
					Thread.sleep(4 * sleepTime);
					if (list[i] > list[i + 1]) {
						red = i + 1;
						int temp = list[i];
						list[i] = list[i + 1];
						list[i + 1] = temp;
						repaint();
						Thread.sleep(4 * sleepTime);
						needNextPass = true;
					}
				}
				green = size - k;
			}
			green = 0;
			red = -1;
		} catch (InterruptedException e) {
		}
		repaint();
	}
	
	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		int columnWidth = (getWidth() - 4 * BORDER_WIDTH) / size;
		int columnHeight = (getHeight() - 4 * BORDER_WIDTH) / size;
		for (int i = 0; i < (green == -1 ? list.length : green); i++) {
			g.setColor(Color.BLACK);
			g.fillRect(2 * BORDER_WIDTH + columnWidth * i, getHeight() - list[i] * columnHeight - 2 * BORDER_WIDTH, columnWidth, list[i] * columnHeight);
			g.setColor(new Color(0xC0C0C0));
			g.drawRect(2 * BORDER_WIDTH + columnWidth * i, getHeight() - list[i] * columnHeight - 2 * BORDER_WIDTH, columnWidth, list[i] * columnHeight);			
		}
		if(green != -1) {
			for (int i = green; i < list.length; i++) {
				g.setColor(new Color(0x556B2F));
				g.fillRect(2 * BORDER_WIDTH + columnWidth * i, getHeight() - list[i] * columnHeight - 2 * BORDER_WIDTH, columnWidth, list[i] * columnHeight);
				g.setColor(new Color(0xC0C0C0));
				g.drawRect(2 * BORDER_WIDTH + columnWidth * i, getHeight() - list[i] * columnHeight - 2 * BORDER_WIDTH, columnWidth, list[i] * columnHeight);			
			}
		}
		if(red != -1) {
			g.setColor(Color.RED);
			g.fillRect(2 * BORDER_WIDTH + columnWidth * red, getHeight() - list[red] * columnHeight - 2 * BORDER_WIDTH, columnWidth, list[red] * columnHeight);
			g.setColor(new Color(0xc0c0c0));
			g.drawRect(2 * BORDER_WIDTH + columnWidth * red, getHeight() - list[red] * columnHeight - 2 * BORDER_WIDTH, columnWidth, list[red] * columnHeight);
		}
	}
	
}

