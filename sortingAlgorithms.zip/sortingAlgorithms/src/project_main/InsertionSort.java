package project_main;

import java.awt.Color;
import java.awt.Graphics;

@SuppressWarnings("serial")
public class InsertionSort extends SortingPanel {
	private int red = -1;
	private int green = -1;
	
	public InsertionSort(int[] list) {
		super(list);
	}

	@Override
	public void reset() {
		red = -1;
		green = -1;		
	}

	@Override
	public void run() {
		try {
			for (int i = 1; i < list.length; i++) {
				green = i;
				red = green;
				int k;
				for (k = i - 1; k >= 0 && list[k] > list[k + 1]; k--) {
					Thread.sleep(3 * sleepTime);
					repaint();
					red = k + 1;
					repaint();
					Thread.sleep(4 * sleepTime);
					int tmp = list[k + 1]; 
					list[k + 1] = list[k];
					list[k] = tmp;
				}
				red = k + 1;
				repaint();
			}
			red = -1;
		} catch (InterruptedException e) {
		}
		repaint();
	}
	
	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		int columnWidth = (getWidth() - 4 * BORDER_WIDTH) / size;
		int columnHeight = (getHeight() - 4 * BORDER_WIDTH) / size;
		for (int i = (green == -1 ? 0 : green); i < list.length; i++) {
			g.setColor(Color.BLACK);
			g.fillRect(2 * BORDER_WIDTH + columnWidth * i, getHeight() - list[i] * columnHeight - 2 * BORDER_WIDTH, columnWidth, list[i] * columnHeight);
			g.setColor(new Color(0xC0C0C0));
			g.drawRect(2 * BORDER_WIDTH + columnWidth * i, getHeight() - list[i] * columnHeight - 2 * BORDER_WIDTH, columnWidth, list[i] * columnHeight);			
		}
		for (int i = 0; i <= green; i++) {
			g.setColor(new Color(0x556B2F));
			g.fillRect(2 * BORDER_WIDTH + columnWidth * i, getHeight() - list[i] * columnHeight - 2 * BORDER_WIDTH, columnWidth, list[i] * columnHeight);
			g.setColor(new Color(0xC0C0C0));
			g.drawRect(2 * BORDER_WIDTH + columnWidth * i, getHeight() - list[i] * columnHeight - 2 * BORDER_WIDTH, columnWidth, list[i] * columnHeight);			
		}
		if(red != -1) {
			g.setColor(Color.RED);
			g.fillRect(2 * BORDER_WIDTH + columnWidth * red, getHeight() - list[red] * columnHeight - 2 * BORDER_WIDTH, columnWidth, list[red] * columnHeight);
			g.setColor(new Color(0xC0C0C0));
			g.drawRect(2 * BORDER_WIDTH + columnWidth * red, getHeight() - list[red] * columnHeight - 2 * BORDER_WIDTH, columnWidth, list[red] * columnHeight);
		}
	}

}
