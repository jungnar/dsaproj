package project_main;

import java.awt.Color;
import java.awt.Graphics;

@SuppressWarnings("serial")
public class MergeSort extends SortingPanel {
	private int red = -1;
	private int blue = -1;
	private int green_start = -1;
	private int green_end = -1;
	
	public MergeSort(int[] list) {
		super(list);
	}


	@Override
	public void reset() {
		red = -1;
		blue = -1;
		green_start = -1;
		green_end = -1;
	}

	@Override
	public void run() {
		try {
			mergeSort(0, list.length - 1);
			green_start = 0;
			green_end = size - 1;
		} catch (InterruptedException e) {
		}
		repaint();
	}

	public void mergeSort(int start, int fin) throws InterruptedException {
		if ((fin - start) > 0) {
			mergeSort(start, start + (fin - start) / 2);
			mergeSort(start + (fin - start) / 2 + 1, fin);
			merge(start, start + (fin - start) / 2, start + (fin - start) / 2 + 1, fin);
		}
	}

	public void merge(int start1, int fin1, int start2, int fin2) throws InterruptedException {
		int[] list1 = new int[fin1 - start1 + 1];
		int[] list2 = new int[fin2 - start2 + 1];
		int[] tmp = new int[list1.length + list2.length];
		System.arraycopy(list, start1, list1, 0, list1.length);
		System.arraycopy(list, start2, list2, 0, list2.length);
		Thread.sleep(2 * sleepTime);
		repaint();
	    int current1 = 0;
	    red = start1 + current1;
	    int current2 = 0;
	    blue = start2 + current2;
	    int current3 = 0;

		while (current1 < list1.length && current2 < list2.length) {
			Thread.sleep(2 * sleepTime);
			repaint();
			if (list1[current1] < list2[current2]) {
				tmp[current3++] = list1[current1++];
				red = start1 + current1;
			} else {
				tmp[current3++] = list2[current2++];
				blue = start2 + current2 - 1;
			}
			Thread.sleep(2 * sleepTime);
			repaint();
		}

		while (current1 < list1.length) {
			tmp[current3++] = list1[current1++];
			red = start1 + current1;
			Thread.sleep(2 * sleepTime);
			repaint();
		}

		while (current2 < list2.length) {
			tmp[current3++] = list2[current2++];
			blue = start2 + current2 - 1;
			Thread.sleep(2 * sleepTime);
			repaint();
		}

		red = -1;
		blue = -1;
		green_start = start1;
		for (int i = 0; i < tmp.length; i++) {
			green_end = start1 + i;
			list[start1 + i] =  tmp[i];
			Thread.sleep(2 * sleepTime);
			repaint();
		}
		green_start = -1;
		green_end = -1;
	}

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		int columnWidth = (getWidth() - 4 * BORDER_WIDTH) / size;
		int columnHeight = (getHeight() - 4 * BORDER_WIDTH) / size;
		for (int i = 0; i < list.length; i++) {
			g.setColor(Color.BLACK);
			g.fillRect(2 * BORDER_WIDTH + columnWidth * i, getHeight() - list[i] * columnHeight - 2 * BORDER_WIDTH, columnWidth, list[i] * columnHeight);
			g.setColor(new Color(0xC0C0C0));
			g.drawRect(2 * BORDER_WIDTH + columnWidth * i, getHeight() - list[i] * columnHeight - 2 * BORDER_WIDTH, columnWidth, list[i] * columnHeight);			
		}
		if((green_start != -1)&&(green_end != -1)) {
			for (int i = green_start; i <= green_end; i++) {
				g.setColor(new Color(0x556B2F));
				g.fillRect(2 * BORDER_WIDTH + columnWidth * i, getHeight() - list[i] * columnHeight - 2 * BORDER_WIDTH, columnWidth, list[i] * columnHeight);
				g.setColor(new Color(0xC0C0C0));
				g.drawRect(2 * BORDER_WIDTH + columnWidth * i, getHeight() - list[i] * columnHeight - 2 * BORDER_WIDTH, columnWidth, list[i] * columnHeight);			
			}
		}
		if(red != -1) {
			g.setColor(Color.RED);
			g.fillRect(2 * BORDER_WIDTH + columnWidth * red, getHeight() - list[red] * columnHeight - 2 * BORDER_WIDTH, columnWidth, list[red] * columnHeight);
			g.setColor(new Color(0xC0C0C0));
			g.drawRect(2 * BORDER_WIDTH + columnWidth * red, getHeight() - list[red] * columnHeight - 2 * BORDER_WIDTH, columnWidth, list[red] * columnHeight);
		}
		if(blue != -1) {
			g.setColor(Color.BLUE);
			g.fillRect(2 * BORDER_WIDTH + columnWidth * blue, getHeight() - list[blue] * columnHeight - 2 * BORDER_WIDTH, columnWidth, list[blue] * columnHeight);
			g.setColor(new Color(0xC0C0C0));
			g.drawRect(2 * BORDER_WIDTH + columnWidth * blue, getHeight() - list[blue] * columnHeight - 2 * BORDER_WIDTH, columnWidth, list[blue] * columnHeight);
		}

	}

}
