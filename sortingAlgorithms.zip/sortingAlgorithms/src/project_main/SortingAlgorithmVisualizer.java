package project_main;

import javax.swing.*;
import javax.swing.border.Border;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

@SuppressWarnings("serial")
public class SortingAlgorithmVisualizer extends JFrame {
	private JComboBox<String> sortDropdown;
    private JComboBox<String> sizeDropdown;
    private JComboBox<String> patternDropdown;
    private JButton addButton;
    private JButton startButton;
    private JButton stopButton;
    private JPanel visualizationPanel;
    private Object sort;
    private Object sort2;
    private String sortInfo;
    private int[] list;

    public SortingAlgorithmVisualizer() {
        setTitle("Sorting Algorithm Visualizer");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(666, 110);
        setLayout(new BorderLayout());

        sortDropdown = new JComboBox<>(new String[]{"Bubble", "Selection", "Insertion", "Shell", "Heap", "Merge", "Quick"});
        sizeDropdown = new JComboBox<>(new String[]{"50", "100", "150", "200", "300"});
        patternDropdown = new JComboBox<>(new String[]{"Randomized/Unique", "Randomized/Repeat","Reverse"});
        addButton = new JButton("Add to Panel");
        startButton = new JButton("Start Visualization");
        stopButton = new JButton("Clear All");
        visualizationPanel = new JPanel();
        visualizationPanel.setBackground(new Color(0xC0C0C0));
        visualizationPanel.setSize(640, 360);

        JPanel controlPanel = new JPanel(new FlowLayout());
        JPanel buttonPanel = new JPanel(new FlowLayout());

        controlPanel.add(new JLabel("Sorting Algorithm:"));
        controlPanel.add(sortDropdown);
        controlPanel.add(new JLabel("Size:"));
        controlPanel.add(sizeDropdown);
        controlPanel.add(new JLabel("Pattern:"));
        controlPanel.add(patternDropdown);

        buttonPanel.add(addButton);
        buttonPanel.add(startButton);
        buttonPanel.add(stopButton);

        add(controlPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.SOUTH);
        add(visualizationPanel, BorderLayout.CENTER);
        
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedSort = (String) sortDropdown.getSelectedItem();
                int selectedSize = Integer.parseInt((String) sizeDropdown.getSelectedItem());
                String selectedPattern = (String) patternDropdown.getSelectedItem();
                
                generatePanel(selectedSort, selectedSize, selectedPattern);
                
    			pack();
    			setLocationRelativeTo(null);
    			checkButtons();
            }
        });
        
        
        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (sort != null && sort2 == null) {
                	Thread myThread = new Thread ((Runnable) sort);
                	myThread.start();
                }
                else if (sort != null && sort2 != null){
                	Thread myThread1 = new Thread ((Runnable) sort);
                	Thread myThread2 = new Thread ((Runnable) sort2);
                	myThread1.start();
                	myThread2.start();
                }
                
                addButton.setEnabled(false);
                startButton.setEnabled(false);
            }
        });
        
        stopButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	sort = null;
            	sort2 = null;
            	visualizationPanel.removeAll();
            	repaint();
            	setSize(666,110);
            	setLocationRelativeTo(null);
            	checkButtons();
            	startButton.setEnabled(true);
            }
        });

        setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true);
    }


	protected void checkButtons() {
		if (sort != null && sort2 != null)
			addButton.setEnabled(false);
		else
			addButton.setEnabled(true);
		
	}


	private void generatePanel(String selectedSort, int selectedSize, String selectedPattern) {
		sortInfo = selectedSort + " Sort, " + selectedSize + ", " + selectedPattern;
		list = generatePattern(selectedPattern, selectedSize);
		Object sortHolder = null;
		
		if (selectedSort.equals("Bubble"))
			sortHolder = new BubbleSort(list);
		else if (selectedSort.equals("Selection"))
			sortHolder = new SelectionSort(list);
		else if (selectedSort.equals("Insertion"))
			sortHolder = new InsertionSort(list);
		else if (selectedSort.equals("Shell"))
			sortHolder = new ShellSort(list);
		else if (selectedSort.equals("Heap"))
			sortHolder = new HeapSort(list);
		else if (selectedSort.equals("Merge"))
			sortHolder = new MergeSort(list);
		else
			sortHolder = new QuickSort(list);
		
		JPanel childPanel = new JPanel();

		JLabel sortInfoLabel = new JLabel(sortInfo);
		sortInfoLabel.setHorizontalAlignment(SwingConstants.CENTER);
		sortInfoLabel.setOpaque(true);
	    sortInfoLabel.setForeground(Color.BLACK);
	    sortInfoLabel.setBackground(new Color(0xC0C0C0));	    
	    
	    childPanel.setLayout(new BorderLayout());
	    childPanel.add(sortInfoLabel, BorderLayout.NORTH);
	    childPanel.add((Component) sortHolder);
		
		visualizationPanel.add(childPanel);
		
		if (sort == null)
			sort = sortHolder;
		else {
			Border rightBorder = BorderFactory.createMatteBorder(0, 5, 0, 0, Color.BLACK);
		    childPanel.setBorder(rightBorder);
		    sort2 = sortHolder;
		}
	}


	private int[] generatePattern(String pattern, int size) {
		list = new int[size];
		if (pattern.equals("Randomized/Unique")) {
			for (int i = 0; i < list.length; i++) {
				list[i] = i + 1;
			}
			for (int i = 0; i < list.length; i++) {
				int index = (int) (Math.random() * list.length);
				int temp = list[i];
				list[i] = list[index];
				list[index] = temp;
			}
		}
		
		else if (pattern.equals("Randomized/Repeat")) {
			for (int i = 0; i < list.length; i++) {
	        	int item = 0;
	        	
	        	while (item == 0)
	        		item = (int) (Math.random() * size);
	        	
				list[i] = item;
			}
		}
		
		else {
			for (int i = 0; i < list.length; i++) {
				list[i] = size - i;
			}
		}
		
		return list;
	}


	public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new SortingAlgorithmVisualizer();
            }
        });
    }
}

