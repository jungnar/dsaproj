package project_main;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SortingAlgorithmVisualizer extends JFrame {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JComboBox<String> algorithmDropdown;
    private JComboBox<String> sizeDropdown;
    private JComboBox<String> patternDropdown;
    private JButton startButton;
    private JPanel visualizationPanel;

    public SortingAlgorithmVisualizer() {
        setTitle("Sorting Algorithm Visualizer");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLayout(new BorderLayout());

        // Initialize components
        algorithmDropdown = new JComboBox<>(new String[]{"Bubble", "Selection", "Insertion", "Shell", "Heap", "Merge", "Quick", "Bucket", "Radix"});
        sizeDropdown = new JComboBox<>(new String[]{"100", "1000", "10000"});
        patternDropdown = new JComboBox<>(new String[]{"Randomized/Unique", "Randomized/Repeated","Reverse"});
        startButton = new JButton("Start Visualization");
        visualizationPanel = new JPanel();
        visualizationPanel.setBackground(new Color(0xC0C0C0));

        // Create panels to organize components
        JPanel controlPanel = new JPanel(new FlowLayout());
        JPanel buttonPanel = new JPanel(new FlowLayout());

        // Add components to controlPanel
        controlPanel.add(new JLabel("Algorithm:"));
        controlPanel.add(algorithmDropdown);
        controlPanel.add(new JLabel("Size:"));
        controlPanel.add(sizeDropdown);
        controlPanel.add(new JLabel("Pattern:"));
        controlPanel.add(patternDropdown);

        // Add components to buttonPanel
        buttonPanel.add(startButton);

        // Add panels to the frame
        add(controlPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.SOUTH);
        add(visualizationPanel, BorderLayout.CENTER);

        // Add action listeners to buttons

        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Logic to start/stop sorting visualization
            }
        });

        // Pack and set visible
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }


	public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new SortingAlgorithmVisualizer();
            }
        });
    }
}

