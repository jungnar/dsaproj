package project_main;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JPanel;

@SuppressWarnings("serial")
public abstract class SortingPanel extends JPanel implements Runnable {
	protected static final int BORDER_WIDTH = 10;
	private Dimension prefferedDimension;
	protected int size;
	protected int[] list;
	protected int sleepTime;
	
	public SortingPanel(int[] list) {
		prefferedDimension = new Dimension(640, 360);
		sleepTime = 2;
		setBackground(Color.BLACK);
		setList(list);
	}

	public void setList(int[] list) {
		reset();
		this.size = list.length;
		this.list = java.util.Arrays.copyOf(list, size);
		setBackground(new Color(0xc0c0c0));
	}
	
	@Override
	public Dimension getPreferredSize() {
		return prefferedDimension;
	}
	
	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		
		
	}

	@Override
	public abstract void run();

	public abstract void reset();

}
