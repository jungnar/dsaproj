package project_test;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class BubbleSortVisualization extends JFrame {
    private static final long serialVersionUID = 1L;
    private JPanel panel;
    private int[] array;

    public BubbleSortVisualization() {
        setTitle("Bubble Sort Visualization");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                drawArray(g);
            }
        };
        add(panel);

        JButton sortButton = new JButton("Sort");
        sortButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new Thread(() -> sortArray()).start();
            }
        });
        add(sortButton, BorderLayout.SOUTH);

        generateRandomArray();
        setVisible(true);
    }

    private void generateRandomArray() {
        int size = 50; // Change the size of the array as needed
        array = new int[size];
        for (int i = 0; i < size; i++) {
            array[i] = (int) (Math.random() * 500 + 1); // Adjust the range of random values as needed
        }
    }

    private void drawArray(Graphics g) {
        int barWidth = getWidth() / array.length;

        for (int i = 0; i < array.length; i++) {
            int barHeight = array[i];
            int x = i * barWidth;
            int y = getHeight() - barHeight;
            g.fillRect(x, y, barWidth, barHeight);
        }
    }

    private void sortArray() {
        for (int i = 0; i < array.length - 1; i++) {
            for (int j = 0; j < array.length - i - 1; j++) {
                if (array[j] > array[j + 1]) {
                    // Swap array[j] and array[j+1]
                    int temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;

                    // Redraw the array after the swap
                    SwingUtilities.invokeLater(() -> panel.repaint());
                    try {
                        Thread.sleep(50); // Adjust the delay as needed
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new BubbleSortVisualization());
    }
}