package project_test;

public class Random {
	public static void main(String[] args) {
		int randomValue = (int) (Math.random() * 10000);
		System.out.println(randomValue); // Output will be a random number between 0 and 99999
	}
}
