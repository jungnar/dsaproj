package project_test;
import javax.swing.*;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class musiclayb extends JFrame {

    JButton msc1;
    JButton msc2;
    JButton msc3;

    public musiclayb(){
        ImageIcon icon1 = new ImageIcon("image/mydp.jpg");
        ImageIcon icon2 = new ImageIcon("image/mydp1.jpg");
        ImageIcon icon3 = new ImageIcon("image/mydp2.jpg");

        msc1 = new JButton(icon1);
        msc2 = new JButton(icon2);
        msc3 = new JButton(icon3);

        msc1.setText("Magbalik");
        msc1.setHorizontalTextPosition(SwingConstants.CENTER);
        msc1.setVerticalTextPosition(SwingConstants.BOTTOM);
        
        msc2.setText("Back to December");
        msc2.setHorizontalTextPosition(SwingConstants.CENTER);
        msc2.setVerticalTextPosition(SwingConstants.BOTTOM);
        
        msc3.setText("Wake me up when September ends");
        msc3.setHorizontalTextPosition(SwingConstants.CENTER);
        msc3.setVerticalTextPosition(SwingConstants.BOTTOM);

        setLayout(new FlowLayout());
        add(msc1);
        add(msc2);
        add(msc3);

       
        msc1.addActionListener(new ButtonClickListener());
        msc2.addActionListener(new ButtonClickListener());
        msc3.addActionListener(new ButtonClickListener());
    }

    public static void main(String[]args) {
        musiclayb jbtn = new musiclayb();
        jbtn.setSize(300,300);
        jbtn.setVisible(true);
        jbtn.setLocationRelativeTo(null);
        jbtn.setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    private class ButtonClickListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            SecondJFrame secondJFrame = new SecondJFrame();
            secondJFrame.setVisible(true);
        }
    }
}

class SecondJFrame extends JFrame {
    public SecondJFrame() {
        setSize(400, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

        JLabel titleLabel = new JLabel("Title:");
        JLabel artistLabel = new JLabel("Artist:");

        JTextField titleField = new JTextField(5);
        JTextField artistField = new JTextField(5);

        add(titleLabel);
        add(titleField);
        add(artistLabel);
        add(artistField);
    }
}